# ec2-cicd-demo
CI/CD pipeline with CodePipeline + CodeDeploy to EC2 in auto scaling group
