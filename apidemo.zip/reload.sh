#!/bin/bash

bash stop.sh
bash start.sh
